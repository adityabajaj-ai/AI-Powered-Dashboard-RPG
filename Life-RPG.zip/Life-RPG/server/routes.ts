import type { Express } from "express";
import { createServer, type Server } from "http";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Generate AI insights and 6-month predictions
  app.post("/api/insights/generate", async (req, res) => {
    try {
      const { character, skills, habits, goals } = req.body;

      const prompt = `You are an AI life coach and RPG game master analyzing a player's real-life stats.

Player Profile:
- Name: ${character.name}
- Class: ${character.class}
- Level: ${character.level}
- Total XP: ${character.totalXp}

Skills being trained:
${skills.map((s: any) => `- ${s.name}: Level ${s.level} (${s.xp}/${s.xpToNext} XP, ${s.totalPractices} total practices${s.lastPracticed ? `, last practiced ${new Date(s.lastPracticed).toLocaleDateString()}` : ", never practiced"})`).join("\n")}

Daily Habits:
${habits.map((h: any) => `- ${h.name}: ${h.streak} day streak (best: ${h.longestStreak}), completed ${h.totalCompleted} times`).join("\n")}

Active Goals:
${goals.filter((g: any) => g.status === "active").map((g: any) => `- "${g.title}": ${g.progress}% complete, due ${g.targetDate}`).join("\n")}

Based on this data, provide a JSON response with:
1. Predictions for each skill's level in 6 months based on current practice frequency
2. An overall analysis of the player's progress
3. A motivational message
4. The strongest and weakest areas

Respond ONLY with this JSON structure, no markdown:
{
  "predictions": [
    {
      "skillId": "skill_id",
      "skillName": "Skill Name",
      "currentLevel": 1,
      "projectedLevel": 3,
      "monthsProjected": 6,
      "insight": "Brief insight about this skill's trajectory",
      "tips": ["Actionable tip 1", "Actionable tip 2"]
    }
  ],
  "overallAnalysis": "2-3 sentence analysis of the player's overall progress and habits",
  "motivationalMessage": "An inspiring, personalized message for the player",
  "weakestArea": "Name of the skill/area that needs most attention",
  "strongestArea": "Name of the skill/area where player excels"
}`;

      const response = await openai.chat.completions.create({
        model: "gpt-5-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        max_completion_tokens: 2048,
      });

      const content = response.choices[0]?.message?.content || "{}";
      const parsed = JSON.parse(content);

      // Ensure all skills have predictions
      const predictedIds = new Set(parsed.predictions?.map((p: any) => p.skillId) || []);
      const missingPredictions = skills
        .filter((s: any) => !predictedIds.has(s.id))
        .map((s: any) => ({
          skillId: s.id,
          skillName: s.name,
          currentLevel: s.level,
          projectedLevel: s.level + Math.max(1, Math.floor(s.totalPractices / 10)),
          monthsProjected: 6,
          insight: "Keep practicing consistently to see steady growth.",
          tips: ["Practice daily", "Track your progress"],
        }));

      res.json({
        ...parsed,
        predictions: [...(parsed.predictions || []), ...missingPredictions],
      });
    } catch (error) {
      console.error("Error generating insights:", error);
      res.status(500).json({ error: "Failed to generate insights" });
    }
  });

  // AI Chat advisor
  app.post("/api/insights/chat", async (req, res) => {
    try {
      const { messages, context } = req.body;

      const systemPrompt = `You are an enthusiastic AI life coach and RPG game master helping a player level up their real life. You're motivating, specific, and game-themed in your responses.

Current player stats:
- Name: ${context.character.name}, Level ${context.character.level} ${context.character.class}
- Skills: ${context.skills.map((s: any) => `${s.name} (Lv.${s.level})`).join(", ")}
- Habits: ${context.habits.map((h: any) => `${h.name} (${h.streak} day streak)`).join(", ")}
- Active Quests: ${context.goals.map((g: any) => `${g.title} (${g.progress}%)`).join(", ")}

Be encouraging, specific, and use RPG terminology occasionally (XP, leveling up, quests, etc.). Keep responses concise and actionable. Max 150 words per response.`;

      const response = await openai.chat.completions.create({
        model: "gpt-5-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages.map((m: any) => ({ role: m.role, content: m.content })),
        ],
        max_completion_tokens: 500,
      });

      const reply = response.choices[0]?.message?.content || "I couldn't process that. Please try again.";
      res.json({ reply });
    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ error: "Failed to get AI response" });
    }
  });

  return httpServer;
}
