import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Skills from "@/pages/Skills";
import Habits from "@/pages/Habits";
import Goals from "@/pages/Goals";
import Insights from "@/pages/Insights";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/skills" component={Skills} />
      <Route path="/habits" component={Habits} />
      <Route path="/goals" component={Goals} />
      <Route path="/insights" component={Insights} />
      <Route component={NotFound} />
    </Switch>
  );
}

const sidebarStyle = {
  "--sidebar-width": "17rem",
  "--sidebar-width-icon": "3.5rem",
};

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider style={sidebarStyle as React.CSSProperties}>
          <div className="flex h-screen w-full overflow-hidden bg-background">
            <AppSidebar />
            <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
              <header className="flex items-center h-12 px-4 border-b border-border/50 bg-background/80 backdrop-blur-sm flex-shrink-0">
                <SidebarTrigger
                  className="text-muted-foreground"
                  data-testid="button-sidebar-toggle"
                />
                <div className="flex items-center gap-2 ml-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 rpg-pulse" />
                  <span className="text-xs text-muted-foreground">Life RPG Active</span>
                </div>
              </header>
              <main className="flex-1 overflow-hidden">
                <Router />
              </main>
            </div>
          </div>
        </SidebarProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
