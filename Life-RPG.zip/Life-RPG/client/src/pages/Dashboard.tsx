import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useGameState } from "@/lib/useGameState";
import {
  getCharacterXpPercentage,
  getSkillColor,
  getXpPercentage,
} from "@/lib/gameStore";
import {
  Swords, Flame, Target, TrendingUp, Zap, Star,
  Trophy, Clock, Edit2, Check, X, Sparkles
} from "lucide-react";

export default function Dashboard() {
  const { state, completeHabit, updateCharacter } = useGameState();
  const { character, skills, habits, goals } = state;
  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(character.name);
  const [editingClass, setEditingClass] = useState(false);
  const [classInput, setClassInput] = useState(character.class);

  const xpPct = getCharacterXpPercentage(character);
  const activeHabits = habits.filter((h) => !h.completedToday).slice(0, 4);
  const completedToday = habits.filter((h) => h.completedToday).length;
  const activeGoals = goals.filter((g) => g.status === "active");
  const topSkills = [...skills].sort((a, b) => b.level - a.level).slice(0, 4);
  const totalXpFromHabits = habits.reduce((acc, h) => acc + (h.completedToday ? h.xpReward : 0), 0);

  const classOptions = ["Adventurer", "Warrior", "Scholar", "Mage", "Rogue", "Paladin", "Ranger", "Bard"];

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 max-w-6xl mx-auto space-y-6">
        {/* Hero Character Card */}
        <div className="relative overflow-hidden rounded-lg border border-primary/30 bg-gradient-to-br from-primary/10 via-card to-accent/5 p-6 glow-primary">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent pointer-events-none" />
          <div className="relative flex items-start gap-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-lg bg-primary/20 border-2 border-primary/50 flex items-center justify-center text-4xl float-animation glow-primary">
                {character.avatar}
              </div>
              <div className="absolute -bottom-2 -right-2 w-7 h-7 rounded-md bg-card border border-primary/40 flex items-center justify-center">
                <span className="text-xs font-bold text-primary text-glow-primary">{character.level}</span>
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                {editingName ? (
                  <div className="flex items-center gap-2">
                    <Input
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      className="h-8 text-xl font-bold bg-background/50 border-primary/40 w-40"
                      data-testid="input-character-name"
                    />
                    <Button size="icon" className="h-7 w-7" onClick={() => { updateCharacter({ name: nameInput }); setEditingName(false); }}>
                      <Check className="w-3 h-3" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditingName(false)}>
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <h1 className="text-2xl font-bold text-foreground">{character.name}</h1>
                    <Button size="icon" variant="ghost" className="h-6 w-6 opacity-40" onClick={() => setEditingName(true)} data-testid="button-edit-name">
                      <Edit2 className="w-3 h-3" />
                    </Button>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <span className="text-sm text-muted-foreground">{character.title}</span>
                <span className="text-muted-foreground">•</span>
                {editingClass ? (
                  <div className="flex items-center gap-1 flex-wrap">
                    {classOptions.map((c) => (
                      <button
                        key={c}
                        onClick={() => { updateCharacter({ class: c }); setClassInput(c); setEditingClass(false); }}
                        className={`text-xs px-2 py-0.5 rounded border transition-all ${classInput === c ? "bg-primary/20 border-primary/50 text-primary" : "border-border text-muted-foreground"}`}
                      >
                        {c}
                      </button>
                    ))}
                    <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => setEditingClass(false)}>
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ) : (
                  <button onClick={() => setEditingClass(true)} className="text-sm text-primary font-medium flex items-center gap-1" data-testid="button-edit-class">
                    {character.class} <Edit2 className="w-3 h-3 opacity-50" />
                  </button>
                )}
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="font-medium">Level {character.level} → {character.level + 1}</span>
                  <span className="text-primary font-bold">{xpPct}%</span>
                </div>
                <div className="h-3 bg-background/60 rounded-full overflow-hidden border border-border/50">
                  <div
                    className="h-full xp-bar-fill rounded-full transition-all duration-1000"
                    style={{ width: `${xpPct}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{character.totalXp.toLocaleString()} total XP</span>
                  <span className="text-accent">+{totalXpFromHabits} XP today</span>
                </div>
              </div>
            </div>
          </div>

          {/* Stat chips */}
          <div className="relative mt-5 flex gap-3 flex-wrap">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-background/40 border border-border/50">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              <span className="text-xs text-muted-foreground">
                <span className="text-foreground font-semibold">{completedToday}/{habits.length}</span> habits done
              </span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-background/40 border border-border/50">
              <Target className="w-3.5 h-3.5 text-accent" />
              <span className="text-xs text-muted-foreground">
                <span className="text-foreground font-semibold">{activeGoals.length}</span> active quests
              </span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-background/40 border border-border/50">
              <Swords className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs text-muted-foreground">
                <span className="text-foreground font-semibold">{skills.length}</span> skills trained
              </span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-background/40 border border-border/50">
              <Zap className="w-3.5 h-3.5 text-yellow-400" />
              <span className="text-xs text-muted-foreground">
                <span className="text-foreground font-semibold">{state.totalXpEarned}</span> XP earned
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Today's Habits */}
          <div className="lg:col-span-2">
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                  <Flame className="w-4 h-4 text-orange-400" />
                  Today's Quests
                  <Badge variant="secondary" className="ml-auto text-xs">
                    {completedToday}/{habits.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {habits.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">
                    No habits yet. Add some in the Habits section!
                  </div>
                ) : (
                  habits.map((habit) => {
                    const skill = skills.find((s) => s.id === habit.skillId);
                    const colors = skill ? getSkillColor(skill.color) : getSkillColor("cyan");
                    return (
                      <div
                        key={habit.id}
                        className={`flex items-center gap-3 p-3 rounded-md border transition-all ${
                          habit.completedToday
                            ? "bg-emerald-500/5 border-emerald-500/20 opacity-60"
                            : "bg-card border-border hover-elevate"
                        }`}
                        data-testid={`habit-item-${habit.id}`}
                      >
                        <div className={`w-8 h-8 rounded-md border flex items-center justify-center flex-shrink-0 ${habit.completedToday ? "bg-emerald-500/20 border-emerald-500/30" : `${colors.bg} ${colors.border}`}`}>
                          {habit.completedToday ? (
                            <Check className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Flame className={`w-4 h-4 ${colors.text}`} />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className={`text-sm font-medium ${habit.completedToday ? "line-through text-muted-foreground" : "text-foreground"}`}>
                            {habit.name}
                          </div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className={`text-xs ${colors.text}`}>+{habit.xpReward} XP</span>
                            {habit.streak > 0 && (
                              <span className="text-xs text-orange-400 flex items-center gap-0.5">
                                🔥 {habit.streak}
                              </span>
                            )}
                          </div>
                        </div>
                        {!habit.completedToday && (
                          <Button
                            size="sm"
                            onClick={() => completeHabit(habit.id)}
                            className="flex-shrink-0 h-7 text-xs"
                            data-testid={`button-complete-habit-${habit.id}`}
                          >
                            Complete
                          </Button>
                        )}
                      </div>
                    );
                  })
                )}
              </CardContent>
            </Card>
          </div>

          {/* Top Skills */}
          <div className="space-y-4">
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                  <Star className="w-4 h-4 text-amber-400" />
                  Top Skills
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {topSkills.map((skill, i) => {
                  const colors = getSkillColor(skill.color);
                  const pct = getXpPercentage(skill);
                  return (
                    <div key={skill.id} className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground w-4">{i + 1}</span>
                          <span className={`text-xs font-medium ${colors.text}`}>{skill.name}</span>
                        </div>
                        <Badge variant="outline" className={`text-xs px-1.5 h-4 ${colors.border} ${colors.text}`}>
                          Lv{skill.level}
                        </Badge>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-700`}
                          style={{
                            width: `${pct}%`,
                            background: skill.color === "cyan" ? "hsl(190 90% 55%)" :
                              skill.color === "green" ? "hsl(160 60% 50%)" :
                              skill.color === "amber" ? "hsl(45 90% 60%)" :
                              skill.color === "purple" ? "hsl(265 80% 65%)" :
                              skill.color === "pink" ? "hsl(340 80% 65%)" :
                              "hsl(30 90% 60%)",
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Active Goals */}
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                  <Trophy className="w-4 h-4 text-yellow-400" />
                  Active Quests
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {activeGoals.slice(0, 3).map((goal) => (
                  <div key={goal.id} className="p-2.5 rounded-md bg-muted/30 border border-border/50 space-y-1.5">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-medium text-foreground leading-tight">{goal.title}</span>
                      <span className="text-xs text-primary font-bold flex-shrink-0">+{goal.xpReward}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1 bg-background rounded-full overflow-hidden">
                        <div
                          className="h-full xp-bar-fill rounded-full transition-all duration-500"
                          style={{ width: `${goal.progress}%` }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground">{goal.progress}%</span>
                    </div>
                  </div>
                ))}
                {activeGoals.length === 0 && (
                  <div className="text-xs text-muted-foreground text-center py-3">No active quests</div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Weekly Activity Heatmap */}
        <Card className="border-border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold">
              <TrendingUp className="w-4 h-4 text-accent" />
              Weekly Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 flex-wrap">
              {Array.from({ length: 7 }).map((_, i) => {
                const d = new Date();
                d.setDate(d.getDate() - (6 - i));
                const dayStr = d.toDateString();
                const completedCount = habits.filter((h) =>
                  h.completedDates.some((cd) => new Date(cd).toDateString() === dayStr)
                ).length;
                const intensity = habits.length > 0 ? completedCount / habits.length : 0;
                return (
                  <div key={i} className="flex-1 min-w-0">
                    <div className="text-center text-xs text-muted-foreground mb-1.5">
                      {d.toLocaleDateString("en", { weekday: "short" })[0]}
                    </div>
                    <div
                      className="h-8 rounded-md border transition-all"
                      style={{
                        background: intensity === 0
                          ? "hsl(220 15% 14%)"
                          : `hsl(265 80% ${30 + intensity * 40}%)`,
                        borderColor: intensity === 0
                          ? "hsl(220 15% 20%)"
                          : `hsl(265 80% ${40 + intensity * 30}% / 0.5)`,
                        boxShadow: intensity > 0.5
                          ? `0 0 12px hsl(265 80% 65% / ${intensity * 0.4})`
                          : "none",
                      }}
                      title={`${completedCount}/${habits.length} habits`}
                    />
                    <div className="text-center text-xs text-muted-foreground mt-1">
                      {completedCount}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
