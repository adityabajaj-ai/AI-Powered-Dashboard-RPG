import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useGameState } from "@/lib/useGameState";
import { getSkillColor, getXpPercentage, type SkillCategory } from "@/lib/gameStore";
import {
  Code2, Dumbbell, BookOpen, Brain, Palette, Users, Zap,
  Plus, Star, TrendingUp, Lock, Award
} from "lucide-react";
import { nanoid } from "nanoid";

const SKILL_ICONS = { Code2, Dumbbell, BookOpen, Brain, Palette, Users, Zap, Star, TrendingUp, Award };

const ICON_OPTIONS = ["Code2", "Dumbbell", "BookOpen", "Brain", "Palette", "Users", "Zap", "Star", "Award"];
const COLOR_OPTIONS = ["cyan", "green", "amber", "purple", "pink", "orange"];
const CATEGORY_OPTIONS: SkillCategory[] = ["tech", "wellness", "intellect", "creativity", "social", "combat"];

function SkillIcon({ name, className }: { name: string; className?: string }) {
  const Icon = SKILL_ICONS[name as keyof typeof SKILL_ICONS] || Star;
  return <Icon className={className} />;
}

function SkillNode({ skill, onClick, selected }: {
  skill: ReturnType<typeof useGameState>["state"]["skills"][0];
  onClick: () => void;
  selected: boolean;
}) {
  const colors = getSkillColor(skill.color);
  const pct = getXpPercentage(skill);
  const isMastered = skill.level >= 10;

  return (
    <button
      onClick={onClick}
      className={`relative p-4 rounded-lg border-2 transition-all text-left hover-elevate ${
        isMastered
          ? "skill-node-mastered"
          : selected
          ? "skill-node-active"
          : "bg-card border-border"
      } ${selected ? "scale-[1.02]" : ""}`}
      data-testid={`skill-node-${skill.id}`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 rounded-md border flex items-center justify-center ${colors.bg} ${colors.border}`}>
          <SkillIcon name={skill.icon} className={`w-5 h-5 ${colors.text}`} />
        </div>
        <div className="text-right">
          <div className={`text-sm font-bold ${isMastered ? "shimmer-text" : colors.text} text-glow-primary`}>
            Lv.{skill.level}
          </div>
          {isMastered && <div className="text-xs text-yellow-400">MASTERED</div>}
        </div>
      </div>

      <div className="mb-2">
        <div className="text-sm font-semibold text-foreground mb-0.5">{skill.name}</div>
        <div className="text-xs text-muted-foreground">{skill.category}</div>
      </div>

      <div className="space-y-1">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>XP</span>
          <span>{skill.xp}/{skill.xpToNext}</span>
        </div>
        <div className="h-1.5 bg-background/60 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{
              width: `${pct}%`,
              background: skill.color === "cyan" ? "hsl(190 90% 55%)" :
                skill.color === "green" ? "hsl(160 60% 50%)" :
                skill.color === "amber" ? "hsl(45 90% 60%)" :
                skill.color === "purple" ? "hsl(265 80% 65%)" :
                skill.color === "pink" ? "hsl(340 80% 65%)" :
                "hsl(30 90% 60%)",
            }}
          />
        </div>
      </div>

      {skill.totalPractices > 0 && (
        <div className="mt-2 text-xs text-muted-foreground">
          {skill.totalPractices} practices
        </div>
      )}
    </button>
  );
}

export default function Skills() {
  const { state, addSkill, addXp } = useGameState();
  const { skills } = state;
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [filterCat, setFilterCat] = useState<string>("all");

  const [form, setForm] = useState({
    name: "",
    description: "",
    category: "tech" as SkillCategory,
    icon: "Star",
    color: "cyan",
  });

  const selected = skills.find((s) => s.id === selectedSkill);
  const filtered = filterCat === "all" ? skills : skills.filter((s) => s.category === filterCat);

  function handleAddSkill() {
    if (!form.name.trim()) return;
    addSkill({
      id: nanoid(),
      name: form.name,
      description: form.description,
      category: form.category,
      icon: form.icon,
      color: form.color,
      level: 1,
      xp: 0,
      xpToNext: 100,
      unlockedAt: 1,
      totalPractices: 0,
    });
    setForm({ name: "", description: "", category: "tech", icon: "Star", color: "cyan" });
    setAddOpen(false);
  }

  const colors = selected ? getSkillColor(selected.color) : null;

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <span className="text-primary text-glow-primary">⚔️</span>
              Skill Tree
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">Train your abilities and level up your stats</p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={filterCat} onValueChange={setFilterCat}>
              <SelectTrigger className="h-9 w-36" data-testid="select-skill-filter">
                <SelectValue placeholder="All categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Skills</SelectItem>
                {CATEGORY_OPTIONS.map((c) => (
                  <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Dialog open={addOpen} onOpenChange={setAddOpen}>
              <DialogTrigger asChild>
                <Button size="sm" data-testid="button-add-skill">
                  <Plus className="w-4 h-4 mr-1" />
                  New Skill
                </Button>
              </DialogTrigger>
              <DialogContent className="border-border bg-card">
                <DialogHeader>
                  <DialogTitle>Unlock New Skill</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-2">
                  <div className="space-y-1.5">
                    <Label>Skill Name</Label>
                    <Input
                      placeholder="e.g. Guitar, Chess, Photography..."
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      data-testid="input-skill-name"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Description</Label>
                    <Input
                      placeholder="What does this skill involve?"
                      value={form.description}
                      onChange={(e) => setForm({ ...form, description: e.target.value })}
                      data-testid="input-skill-description"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label>Category</Label>
                      <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v as SkillCategory })}>
                        <SelectTrigger data-testid="select-skill-category">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORY_OPTIONS.map((c) => (
                            <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Color</Label>
                      <div className="flex gap-1.5 flex-wrap pt-1">
                        {COLOR_OPTIONS.map((c) => {
                          const col = getSkillColor(c);
                          return (
                            <button
                              key={c}
                              onClick={() => setForm({ ...form, color: c })}
                              className={`w-6 h-6 rounded border-2 transition-all ${form.color === c ? "scale-125 border-foreground" : "border-border"} ${col.bg}`}
                              data-testid={`color-option-${c}`}
                            />
                          );
                        })}
                      </div>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Icon</Label>
                    <div className="flex gap-2 flex-wrap">
                      {ICON_OPTIONS.map((icon) => (
                        <button
                          key={icon}
                          onClick={() => setForm({ ...form, icon })}
                          className={`w-9 h-9 rounded-md border flex items-center justify-center transition-all ${form.icon === icon ? "border-primary bg-primary/20 text-primary" : "border-border text-muted-foreground"}`}
                          data-testid={`icon-option-${icon}`}
                        >
                          <SkillIcon name={icon} className="w-4 h-4" />
                        </button>
                      ))}
                    </div>
                  </div>
                  <Button
                    className="w-full"
                    onClick={handleAddSkill}
                    disabled={!form.name.trim()}
                    data-testid="button-confirm-add-skill"
                  >
                    Unlock Skill
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Skill Tree Grid */}
          <div className="lg:col-span-2">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {filtered.map((skill) => (
                <SkillNode
                  key={skill.id}
                  skill={skill}
                  onClick={() => setSelectedSkill(selectedSkill === skill.id ? null : skill.id)}
                  selected={selectedSkill === skill.id}
                />
              ))}
            </div>
            {filtered.length === 0 && (
              <div className="text-center py-16 text-muted-foreground">
                <Lock className="w-8 h-8 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No skills in this category yet</p>
              </div>
            )}
          </div>

          {/* Skill Detail Panel */}
          <div>
            {selected && colors ? (
              <Card className="border-border sticky top-0">
                <CardHeader className={`border-b border-border pb-4`}>
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-lg border-2 flex items-center justify-center ${colors.bg} ${colors.border}`}>
                      <SkillIcon name={selected.icon} className={`w-6 h-6 ${colors.text}`} />
                    </div>
                    <div>
                      <CardTitle className="text-base">{selected.name}</CardTitle>
                      <div className="text-xs text-muted-foreground capitalize">{selected.category}</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-4 space-y-4">
                  <p className="text-sm text-muted-foreground">{selected.description || "Train this skill daily to level up."}</p>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Level</span>
                      <span className={`font-bold ${colors.text}`}>
                        {selected.level}
                        {selected.level >= 10 && " ✨"}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">XP Progress</span>
                      <span className="text-foreground font-medium">{selected.xp} / {selected.xpToNext}</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                          width: `${getXpPercentage(selected)}%`,
                          background: selected.color === "cyan" ? "hsl(190 90% 55%)" :
                            selected.color === "green" ? "hsl(160 60% 50%)" :
                            selected.color === "amber" ? "hsl(45 90% 60%)" :
                            selected.color === "purple" ? "hsl(265 80% 65%)" :
                            selected.color === "pink" ? "hsl(340 80% 65%)" :
                            "hsl(30 90% 60%)",
                        }}
                      />
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Total Practices</span>
                      <span className="text-foreground">{selected.totalPractices}</span>
                    </div>
                    {selected.lastPracticed && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Last Practiced</span>
                        <span className="text-foreground text-xs">{new Date(selected.lastPracticed).toLocaleDateString()}</span>
                      </div>
                    )}
                  </div>

                  {/* XP Milestones */}
                  <div>
                    <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-2">Level Milestones</div>
                    <div className="space-y-1.5">
                      {[1, 3, 5, 10].map((lvl) => (
                        <div key={lvl} className={`flex items-center gap-2 text-xs ${selected.level >= lvl ? colors.text : "text-muted-foreground"}`}>
                          <div className={`w-2 h-2 rounded-full flex-shrink-0 ${selected.level >= lvl ? colors.bg + " " + colors.border + " border" : "bg-muted"}`} />
                          <span>Level {lvl} — {lvl === 1 ? "Initiate" : lvl === 3 ? "Apprentice" : lvl === 5 ? "Adept" : "Master"}</span>
                          {selected.level >= lvl && <span className="ml-auto">✓</span>}
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button
                    className="w-full"
                    onClick={() => addXp(selected.id, 25)}
                    data-testid={`button-practice-${selected.id}`}
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    Practice (+25 XP)
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-border/50 border-dashed">
                <CardContent className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center mb-3">
                    <Star className="w-6 h-6 text-primary/40" />
                  </div>
                  <p className="text-sm text-muted-foreground">Select a skill to view details and practice</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
