import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useGameState } from "@/lib/useGameState";
import { getSkillColor, type Goal } from "@/lib/gameStore";
import {
  Target, Plus, Check, Trash2, Calendar, Zap,
  Trophy, ChevronDown, ChevronUp, Edit2, Flag
} from "lucide-react";
import { nanoid } from "nanoid";

function GoalCard({ goal, skills, onUpdate, onDelete }: {
  goal: Goal;
  skills: ReturnType<typeof useGameState>["state"]["skills"];
  onUpdate: (g: Goal) => void;
  onDelete: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [editProgress, setEditProgress] = useState(false);
  const [progressVal, setProgressVal] = useState(goal.progress);

  const skill = skills.find((s) => s.id === goal.skillId);
  const colors = skill ? getSkillColor(skill.color) : getSkillColor("cyan");

  const completedMilestones = goal.milestones.filter((m) => m.completed).length;
  const daysLeft = Math.max(0, Math.ceil((new Date(goal.targetDate).getTime() - Date.now()) / 86400000));

  function toggleMilestone(milestoneId: string) {
    const milestones = goal.milestones.map((m) => {
      if (m.id !== milestoneId) return m;
      return { ...m, completed: !m.completed, completedAt: !m.completed ? new Date().toISOString() : undefined };
    });
    const newProgress = Math.round((milestones.filter((m) => m.completed).length / milestones.length) * 100);
    onUpdate({ ...goal, milestones, progress: newProgress });
  }

  function saveProgress() {
    onUpdate({ ...goal, progress: progressVal });
    setEditProgress(false);
  }

  function markComplete() {
    onUpdate({
      ...goal,
      status: "completed",
      progress: 100,
      completedAt: new Date().toISOString(),
    });
  }

  const statusColors = {
    active: "text-emerald-400 bg-emerald-400/10 border-emerald-400/30",
    completed: "text-yellow-400 bg-yellow-400/10 border-yellow-400/30",
    paused: "text-muted-foreground bg-muted border-border",
  };

  return (
    <Card className={`border transition-all ${goal.status === "completed" ? "border-yellow-400/20 bg-yellow-400/5" : "border-border"}`} data-testid={`goal-card-${goal.id}`}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <div className={`w-10 h-10 rounded-md border flex items-center justify-center flex-shrink-0 mt-0.5 ${goal.status === "completed" ? "bg-yellow-400/10 border-yellow-400/30" : `${colors.bg} ${colors.border}`}`}>
              {goal.status === "completed" ? (
                <Trophy className="w-5 h-5 text-yellow-400" />
              ) : (
                <Target className={`w-5 h-5 ${colors.text}`} />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm font-semibold text-foreground">{goal.title}</h3>
                <Badge variant="outline" className={`text-xs h-5 ${statusColors[goal.status]}`}>
                  {goal.status}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{goal.description}</p>
              <div className="flex items-center gap-3 mt-2 flex-wrap">
                {skill && (
                  <Badge variant="outline" className={`text-xs h-5 ${colors.border} ${colors.text}`}>
                    {skill.name}
                  </Badge>
                )}
                <span className={`text-xs font-medium ${colors.text}`}>+{goal.xpReward} XP</span>
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {daysLeft > 0 ? `${daysLeft} days left` : "Overdue"}
                </span>
                <span className="text-xs text-muted-foreground">
                  {completedMilestones}/{goal.milestones.length} milestones
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 flex-shrink-0">
            {goal.status !== "completed" && (
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs text-yellow-400 border-yellow-400/30"
                onClick={markComplete}
                data-testid={`button-complete-goal-${goal.id}`}
              >
                <Trophy className="w-3 h-3 mr-1" />
                Complete
              </Button>
            )}
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 text-muted-foreground"
              onClick={() => setExpanded(!expanded)}
              data-testid={`button-expand-goal-${goal.id}`}
            >
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </Button>
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 text-muted-foreground"
              onClick={() => onDelete(goal.id)}
              data-testid={`button-delete-goal-${goal.id}`}
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-4 space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Progress</span>
            <div className="flex items-center gap-2">
              <span className={`font-bold ${colors.text}`}>{goal.progress}%</span>
              {goal.status !== "completed" && (
                <button
                  onClick={() => setEditProgress(!editProgress)}
                  className="text-muted-foreground"
                  data-testid={`button-edit-progress-${goal.id}`}
                >
                  <Edit2 className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
          {editProgress ? (
            <div className="space-y-2">
              <Slider
                value={[progressVal]}
                onValueChange={([v]) => setProgressVal(v)}
                max={100}
                step={5}
                className="my-2"
              />
              <div className="flex gap-2">
                <Button size="sm" className="h-7 text-xs flex-1" onClick={saveProgress}>Save {progressVal}%</Button>
                <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setEditProgress(false)}>Cancel</Button>
              </div>
            </div>
          ) : (
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-700 ${goal.status === "completed" ? "" : ""}`}
                style={{
                  width: `${goal.progress}%`,
                  background: goal.status === "completed"
                    ? "hsl(45 90% 60%)"
                    : skill?.color === "cyan" ? "hsl(190 90% 55%)" :
                      skill?.color === "green" ? "hsl(160 60% 50%)" :
                      skill?.color === "amber" ? "hsl(45 90% 60%)" :
                      skill?.color === "purple" ? "hsl(265 80% 65%)" :
                      skill?.color === "pink" ? "hsl(340 80% 65%)" :
                      "hsl(30 90% 60%)",
                }}
              />
            </div>
          )}
        </div>

        {/* Expanded milestones */}
        {expanded && goal.milestones.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border/40 space-y-2">
            <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Milestones</div>
            {goal.milestones.map((m) => (
              <button
                key={m.id}
                onClick={() => toggleMilestone(m.id)}
                className={`w-full flex items-center gap-3 p-2.5 rounded-md border text-left transition-all ${
                  m.completed
                    ? "bg-emerald-500/5 border-emerald-500/20"
                    : "border-border/50 hover-elevate"
                }`}
                data-testid={`milestone-${m.id}`}
              >
                <div className={`w-5 h-5 rounded border flex items-center justify-center flex-shrink-0 ${
                  m.completed ? "bg-emerald-500/20 border-emerald-500/40" : "border-border"
                }`}>
                  {m.completed && <Check className="w-3 h-3 text-emerald-400" />}
                </div>
                <span className={`text-xs font-medium ${m.completed ? "line-through text-muted-foreground" : "text-foreground"}`}>
                  {m.title}
                </span>
                {m.completedAt && (
                  <span className="text-xs text-muted-foreground ml-auto">
                    {new Date(m.completedAt).toLocaleDateString()}
                  </span>
                )}
              </button>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function Goals() {
  const { state, addGoal, updateGoal, deleteGoal } = useGameState();
  const { goals, skills } = state;
  const [addOpen, setAddOpen] = useState(false);
  const [filter, setFilter] = useState<"all" | "active" | "completed">("all");

  const [form, setForm] = useState({
    title: "",
    description: "",
    skillId: skills[0]?.id || "",
    targetDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    xpReward: 200,
    milestones: [""] as string[],
  });

  function handleAdd() {
    if (!form.title.trim()) return;
    addGoal({
      id: nanoid(),
      title: form.title,
      description: form.description,
      skillId: form.skillId || skills[0]?.id || "coding",
      targetDate: form.targetDate,
      progress: 0,
      status: "active",
      milestones: form.milestones.filter((m) => m.trim()).map((m) => ({
        id: nanoid(),
        title: m,
        completed: false,
      })),
      xpReward: form.xpReward,
      createdAt: new Date().toISOString(),
    });
    setForm({
      title: "", description: "", skillId: skills[0]?.id || "",
      targetDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      xpReward: 200, milestones: [""],
    });
    setAddOpen(false);
  }

  const filtered = filter === "all" ? goals : goals.filter((g) => g.status === filter);
  const completedCount = goals.filter((g) => g.status === "completed").length;
  const activeCount = goals.filter((g) => g.status === "active").length;
  const totalXpFromGoals = goals.filter((g) => g.status === "completed").reduce((acc, g) => acc + g.xpReward, 0);

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Target className="w-6 h-6 text-accent" />
              Quest Board
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">Set epic goals and conquer them one milestone at a time</p>
          </div>
          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-add-goal">
                <Plus className="w-4 h-4 mr-1" />
                New Quest
              </Button>
            </DialogTrigger>
            <DialogContent className="border-border bg-card max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Quest</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-2 max-h-[70vh] overflow-y-auto pr-1">
                <div className="space-y-1.5">
                  <Label>Quest Title</Label>
                  <Input
                    placeholder="e.g. Learn to play guitar..."
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    data-testid="input-goal-title"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Description</Label>
                  <Textarea
                    placeholder="What does success look like?"
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className="resize-none"
                    data-testid="input-goal-description"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Linked Skill</Label>
                    <Select value={form.skillId} onValueChange={(v) => setForm({ ...form, skillId: v })}>
                      <SelectTrigger data-testid="select-goal-skill">
                        <SelectValue placeholder="Select skill" />
                      </SelectTrigger>
                      <SelectContent>
                        {skills.map((s) => (
                          <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>XP Reward</Label>
                    <Select
                      value={String(form.xpReward)}
                      onValueChange={(v) => setForm({ ...form, xpReward: Number(v) })}
                    >
                      <SelectTrigger data-testid="select-goal-xp">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[100, 200, 300, 500, 750, 1000].map((xp) => (
                          <SelectItem key={xp} value={String(xp)}>+{xp} XP</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label>Target Date</Label>
                  <Input
                    type="date"
                    value={form.targetDate}
                    onChange={(e) => setForm({ ...form, targetDate: e.target.value })}
                    className="text-foreground"
                    data-testid="input-goal-date"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Milestones (optional)</Label>
                  {form.milestones.map((m, i) => (
                    <div key={i} className="flex gap-2">
                      <Input
                        placeholder={`Milestone ${i + 1}`}
                        value={m}
                        onChange={(e) => {
                          const milestones = [...form.milestones];
                          milestones[i] = e.target.value;
                          setForm({ ...form, milestones });
                        }}
                        data-testid={`input-milestone-${i}`}
                      />
                      {i === form.milestones.length - 1 && (
                        <Button
                          size="icon"
                          variant="outline"
                          className="flex-shrink-0"
                          onClick={() => setForm({ ...form, milestones: [...form.milestones, ""] })}
                          data-testid="button-add-milestone"
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
                <Button
                  className="w-full"
                  onClick={handleAdd}
                  disabled={!form.title.trim()}
                  data-testid="button-confirm-add-goal"
                >
                  Create Quest
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Active Quests", value: activeCount, icon: Flag, color: "text-accent" },
            { label: "Completed", value: completedCount, icon: Trophy, color: "text-yellow-400" },
            { label: "XP Earned", value: totalXpFromGoals, icon: Zap, color: "text-primary" },
          ].map((s) => (
            <Card key={s.label} className="border-border">
              <CardContent className="p-4 flex items-center gap-3">
                <s.icon className={`w-5 h-5 ${s.color} flex-shrink-0`} />
                <div>
                  <div className={`text-lg font-bold ${s.color}`}>{s.value}</div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2">
          {(["all", "active", "completed"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all capitalize ${
                filter === f
                  ? "bg-primary/20 text-primary border border-primary/30"
                  : "text-muted-foreground border border-border/50"
              }`}
              data-testid={`filter-${f}`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Goals */}
        <div className="space-y-3">
          {filtered.length === 0 ? (
            <Card className="border-border/50 border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-16 text-center">
                <Target className="w-10 h-10 text-accent/30 mb-3" />
                <p className="text-sm font-medium text-muted-foreground mb-1">No quests here</p>
                <p className="text-xs text-muted-foreground/60">Create your first quest to start your journey</p>
              </CardContent>
            </Card>
          ) : (
            filtered.map((goal) => (
              <GoalCard
                key={goal.id}
                goal={goal}
                skills={skills}
                onUpdate={updateGoal}
                onDelete={deleteGoal}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}
