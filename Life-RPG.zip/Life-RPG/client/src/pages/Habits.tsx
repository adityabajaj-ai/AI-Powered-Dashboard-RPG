import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useGameState } from "@/lib/useGameState";
import { getSkillColor } from "@/lib/gameStore";
import {
  Flame, Plus, Check, Trash2, Zap, Trophy, Target, Clock, Star
} from "lucide-react";
import { nanoid } from "nanoid";

export default function Habits() {
  const { state, completeHabit, addHabit, deleteHabit } = useGameState();
  const { habits, skills } = state;
  const [addOpen, setAddOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [form, setForm] = useState({
    name: "",
    description: "",
    skillId: skills[0]?.id || "",
    xpReward: 25,
    frequency: "daily" as "daily" | "weekly",
  });

  const completedToday = habits.filter((h) => h.completedToday).length;
  const totalXpToday = habits.filter((h) => h.completedToday).reduce((acc, h) => acc + h.xpReward, 0);
  const longestStreak = Math.max(0, ...habits.map((h) => h.longestStreak));
  const currentBestStreak = Math.max(0, ...habits.map((h) => h.streak));

  function handleAdd() {
    if (!form.name.trim()) return;
    addHabit({
      id: nanoid(),
      name: form.name,
      description: form.description,
      skillId: form.skillId || skills[0]?.id || "coding",
      xpReward: form.xpReward,
      streak: 0,
      longestStreak: 0,
      completedToday: false,
      completedDates: [],
      createdAt: new Date().toISOString(),
      icon: "Flame",
      frequency: form.frequency,
    });
    setForm({ name: "", description: "", skillId: skills[0]?.id || "", xpReward: 25, frequency: "daily" });
    setAddOpen(false);
  }

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Flame className="w-6 h-6 text-orange-400" />
              Daily Quests
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">Build habits, earn XP, level up your life</p>
          </div>
          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-add-habit">
                <Plus className="w-4 h-4 mr-1" />
                New Habit
              </Button>
            </DialogTrigger>
            <DialogContent className="border-border bg-card">
              <DialogHeader>
                <DialogTitle>Create Daily Quest</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-2">
                <div className="space-y-1.5">
                  <Label>Habit Name</Label>
                  <Input
                    placeholder="e.g. Morning Run, Read 20 pages..."
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    data-testid="input-habit-name"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Description (optional)</Label>
                  <Input
                    placeholder="Brief description of the habit"
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    data-testid="input-habit-description"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Linked Skill</Label>
                    <Select value={form.skillId} onValueChange={(v) => setForm({ ...form, skillId: v })}>
                      <SelectTrigger data-testid="select-habit-skill">
                        <SelectValue placeholder="Select skill" />
                      </SelectTrigger>
                      <SelectContent>
                        {skills.map((s) => (
                          <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>XP Reward</Label>
                    <Select
                      value={String(form.xpReward)}
                      onValueChange={(v) => setForm({ ...form, xpReward: Number(v) })}
                    >
                      <SelectTrigger data-testid="select-habit-xp">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[10, 15, 20, 25, 30, 40, 50, 75, 100].map((xp) => (
                          <SelectItem key={xp} value={String(xp)}>+{xp} XP</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button
                  className="w-full"
                  onClick={handleAdd}
                  disabled={!form.name.trim()}
                  data-testid="button-confirm-add-habit"
                >
                  Add Quest
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            {
              label: "Done Today",
              value: `${completedToday}/${habits.length}`,
              icon: Check,
              color: "text-emerald-400",
              bg: "bg-emerald-400/10",
            },
            {
              label: "XP Today",
              value: `+${totalXpToday}`,
              icon: Zap,
              color: "text-yellow-400",
              bg: "bg-yellow-400/10",
            },
            {
              label: "Best Streak",
              value: `${currentBestStreak} days`,
              icon: Flame,
              color: "text-orange-400",
              bg: "bg-orange-400/10",
            },
            {
              label: "All-Time Best",
              value: `${longestStreak} days`,
              icon: Trophy,
              color: "text-amber-400",
              bg: "bg-amber-400/10",
            },
          ].map((stat) => (
            <Card key={stat.label} className="border-border">
              <CardContent className="p-4">
                <div className={`w-8 h-8 rounded-md ${stat.bg} flex items-center justify-center mb-2`}>
                  <stat.icon className={`w-4 h-4 ${stat.color}`} />
                </div>
                <div className={`text-lg font-bold ${stat.color}`}>{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Habits List */}
        <div className="space-y-3">
          {habits.length === 0 ? (
            <Card className="border-border/50 border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-16 text-center">
                <Flame className="w-10 h-10 text-orange-400/30 mb-3" />
                <p className="text-sm font-medium text-muted-foreground mb-1">No habits yet</p>
                <p className="text-xs text-muted-foreground/60">Create your first daily quest to start earning XP</p>
              </CardContent>
            </Card>
          ) : (
            habits.map((habit) => {
              const skill = skills.find((s) => s.id === habit.skillId);
              const colors = skill ? getSkillColor(skill.color) : getSkillColor("cyan");

              return (
                <Card
                  key={habit.id}
                  className={`border transition-all ${habit.completedToday ? "border-emerald-500/25 bg-emerald-500/5" : "border-border hover-elevate"}`}
                  data-testid={`habit-card-${habit.id}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      {/* Completion button */}
                      <button
                        onClick={() => !habit.completedToday && completeHabit(habit.id)}
                        disabled={habit.completedToday}
                        className={`w-12 h-12 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                          habit.completedToday
                            ? "bg-emerald-500/20 border-emerald-500/50"
                            : `${colors.bg} ${colors.border} cursor-pointer`
                        }`}
                        data-testid={`button-complete-${habit.id}`}
                      >
                        {habit.completedToday ? (
                          <Check className="w-6 h-6 text-emerald-400" />
                        ) : (
                          <Flame className={`w-5 h-5 ${colors.text}`} />
                        )}
                      </button>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className={`text-sm font-semibold ${habit.completedToday ? "line-through text-muted-foreground" : "text-foreground"}`}>
                            {habit.name}
                          </h3>
                          {habit.streak > 0 && (
                            <span className="text-xs text-orange-400 font-bold flex items-center gap-0.5">
                              🔥 {habit.streak} day streak
                            </span>
                          )}
                        </div>
                        {habit.description && (
                          <p className="text-xs text-muted-foreground mt-0.5">{habit.description}</p>
                        )}
                        <div className="flex items-center gap-3 mt-2 flex-wrap">
                          {skill && (
                            <Badge variant="outline" className={`text-xs h-5 ${colors.border} ${colors.text}`}>
                              {skill.name}
                            </Badge>
                          )}
                          <span className={`text-xs font-medium ${colors.text}`}>
                            +{habit.xpReward} XP
                          </span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {habit.frequency}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {habit.completedDates.length} completed
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {!habit.completedToday && (
                          <Button
                            size="sm"
                            onClick={() => completeHabit(habit.id)}
                            className="h-8 text-xs"
                            data-testid={`button-complete-action-${habit.id}`}
                          >
                            <Check className="w-3 h-3 mr-1" />
                            Done
                          </Button>
                        )}
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-muted-foreground"
                          onClick={() => setDeleteId(habit.id)}
                          data-testid={`button-delete-habit-${habit.id}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>

                    {/* Streak visualization */}
                    {habit.completedDates.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-border/40">
                        <div className="text-xs text-muted-foreground mb-2">Last 7 days</div>
                        <div className="flex gap-1.5">
                          {Array.from({ length: 7 }).map((_, i) => {
                            const d = new Date();
                            d.setDate(d.getDate() - (6 - i));
                            const dayStr = d.toDateString();
                            const done = habit.completedDates.some(
                              (cd) => new Date(cd).toDateString() === dayStr
                            );
                            return (
                              <div
                                key={i}
                                className={`flex-1 h-2 rounded-full transition-all ${
                                  done
                                    ? colors.bg.replace("/10", "/60") + " border " + colors.border
                                    : "bg-muted"
                                }`}
                                title={d.toLocaleDateString()}
                              />
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {/* Delete confirmation */}
        <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
          <AlertDialogContent className="bg-card border-border">
            <AlertDialogHeader>
              <AlertDialogTitle>Delete this habit?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently remove the habit and all its tracking data.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-destructive-foreground"
                onClick={() => { if (deleteId) { deleteHabit(deleteId); setDeleteId(null); } }}
                data-testid="button-confirm-delete"
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
