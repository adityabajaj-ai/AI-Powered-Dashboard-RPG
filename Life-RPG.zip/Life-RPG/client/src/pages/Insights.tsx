import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useGameState } from "@/lib/useGameState";
import { getSkillColor } from "@/lib/gameStore";
import {
  Sparkles, TrendingUp, Brain, Zap, RefreshCw, Send,
  Star, Target, Flame, ChevronRight, MessageSquare
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface InsightResponse {
  predictions: Array<{
    skillId: string;
    skillName: string;
    currentLevel: number;
    projectedLevel: number;
    monthsProjected: number;
    insight: string;
    tips: string[];
  }>;
  overallAnalysis: string;
  motivationalMessage: string;
  weakestArea: string;
  strongestArea: string;
}

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export default function Insights() {
  const { state } = useGameState();
  const { skills, habits, goals, character } = state;

  const [insights, setInsights] = useState<InsightResponse | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [activeTab, setActiveTab] = useState<"predictions" | "chat">("predictions");

  const generateInsights = useMutation({
    mutationFn: async () => {
      const payload = {
        character: {
          name: character.name,
          level: character.level,
          class: character.class,
          totalXp: character.totalXp,
        },
        skills: skills.map((s) => ({
          id: s.id,
          name: s.name,
          level: s.level,
          xp: s.xp,
          xpToNext: s.xpToNext,
          totalPractices: s.totalPractices,
          lastPracticed: s.lastPracticed,
        })),
        habits: habits.map((h) => ({
          name: h.name,
          skillId: h.skillId,
          streak: h.streak,
          longestStreak: h.longestStreak,
          totalCompleted: h.completedDates.length,
          xpReward: h.xpReward,
        })),
        goals: goals.map((g) => ({
          title: g.title,
          skillId: g.skillId,
          progress: g.progress,
          status: g.status,
          targetDate: g.targetDate,
        })),
      };
      const res = await apiRequest("POST", "/api/insights/generate", payload);
      return res.json() as Promise<InsightResponse>;
    },
    onSuccess: (data) => setInsights(data),
  });

  const sendChat = useMutation({
    mutationFn: async (message: string) => {
      const newMessages: ChatMessage[] = [...chatMessages, { role: "user", content: message }];
      const payload = {
        messages: newMessages,
        context: {
          character: { name: character.name, level: character.level, class: character.class },
          skills: skills.map((s) => ({ name: s.name, level: s.level })),
          habits: habits.map((h) => ({ name: h.name, streak: h.streak })),
          goals: goals.filter((g) => g.status === "active").map((g) => ({ title: g.title, progress: g.progress })),
        },
      };
      const res = await apiRequest("POST", "/api/insights/chat", payload);
      return res.json() as Promise<{ reply: string }>;
    },
    onMutate: (message) => {
      setChatMessages((prev) => [...prev, { role: "user", content: message }]);
      setChatInput("");
    },
    onSuccess: (data) => {
      setChatMessages((prev) => [...prev, { role: "assistant", content: data.reply }]);
    },
  });

  function handleSendChat() {
    if (!chatInput.trim()) return;
    sendChat.mutate(chatInput.trim());
  }

  const topSkill = [...skills].sort((a, b) => b.level * b.xp - a.level * a.xp)[0];
  const weakSkill = [...skills].sort((a, b) => a.totalPractices - b.totalPractices)[0];

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              Optimus Prime
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">AI-powered predictions and insights for your journey</p>
          </div>
          <Badge variant="outline" className="text-xs border-accent/30 text-accent">
            Powered by OpenAI
          </Badge>
        </div>

        {/* Quick Stats for Context */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "Current Level", value: character.level, icon: Star, color: "text-primary" },
            { label: "Skills Training", value: skills.length, icon: Zap, color: "text-accent" },
            { label: "Active Habits", value: habits.length, icon: Flame, color: "text-orange-400" },
            { label: "Active Quests", value: goals.filter((g) => g.status === "active").length, icon: Target, color: "text-yellow-400" },
          ].map((s) => (
            <Card key={s.label} className="border-border">
              <CardContent className="p-3 flex items-center gap-2">
                <s.icon className={`w-4 h-4 ${s.color} flex-shrink-0`} />
                <div>
                  <div className={`text-base font-bold ${s.color}`}>{s.value}</div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          {[
            { id: "predictions", label: "6-Month Predictions", icon: TrendingUp },
            { id: "chat", label: "AI Advisor", icon: MessageSquare },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as "predictions" | "chat")}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? "bg-primary/20 text-primary border border-primary/30"
                  : "text-muted-foreground border border-border/50"
              }`}
              data-testid={`tab-${tab.id}`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Predictions Tab */}
        {activeTab === "predictions" && (
          <div className="space-y-4">
            {!insights && !generateInsights.isPending && (
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="flex flex-col items-center justify-center py-12 text-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center float-animation glow-primary">
                    <Brain className="w-8 h-8 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-foreground mb-1">Ready to reveal your future?</h3>
                    <p className="text-sm text-muted-foreground max-w-sm">
                      Optimus Prime analyzes your skills, habits, and goals to predict your progress over the next 6 months.
                    </p>
                  </div>
                  <Button
                    onClick={() => generateInsights.mutate()}
                    className="gap-2"
                    data-testid="button-generate-insights"
                  >
                    <Sparkles className="w-4 h-4" />
                    Consult Optimus Prime
                  </Button>
                </CardContent>
              </Card>
            )}

            {generateInsights.isPending && (
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="flex flex-col items-center justify-center py-12 text-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center">
                    <RefreshCw className="w-8 h-8 text-primary animate-spin" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-foreground mb-1">Optimus Prime is analyzing...</h3>
                    <p className="text-sm text-muted-foreground">Analyzing your journey and predicting your path</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {generateInsights.isError && (
              <Card className="border-destructive/30 bg-destructive/5">
                <CardContent className="p-4 flex items-center justify-between gap-3">
                  <p className="text-sm text-destructive">Failed to generate insights. Please try again.</p>
                  <Button variant="outline" size="sm" onClick={() => generateInsights.mutate()}>
                    Retry
                  </Button>
                </CardContent>
              </Card>
            )}

            {insights && (
              <div className="space-y-5">
                {/* Overall Analysis */}
                <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-semibold flex items-center gap-2">
                      <Brain className="w-4 h-4 text-primary" />
                      Optimus Prime's Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-foreground leading-relaxed">{insights.overallAnalysis}</p>
                    <div className="p-3 rounded-md bg-primary/10 border border-primary/20">
                      <p className="text-sm text-primary font-medium italic">"{insights.motivationalMessage}"</p>
                    </div>
                    <div className="flex gap-3 flex-wrap">
                      <div className="flex items-center gap-2 text-xs">
                        <Star className="w-3.5 h-3.5 text-yellow-400" />
                        <span className="text-muted-foreground">Strongest:</span>
                        <span className="text-foreground font-medium">{insights.strongestArea}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <TrendingUp className="w-3.5 h-3.5 text-accent" />
                        <span className="text-muted-foreground">Focus on:</span>
                        <span className="text-foreground font-medium">{insights.weakestArea}</span>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => generateInsights.mutate()}
                      disabled={generateInsights.isPending}
                      className="h-7 text-xs"
                      data-testid="button-refresh-insights"
                    >
                      <RefreshCw className={`w-3 h-3 mr-1 ${generateInsights.isPending ? "animate-spin" : ""}`} />
                      Refresh
                    </Button>
                  </CardContent>
                </Card>

                {/* Skill Predictions */}
                <div>
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                    6-Month Skill Projections
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {insights.predictions.map((pred) => {
                      const skill = skills.find((s) => s.id === pred.skillId);
                      const colors = skill ? getSkillColor(skill.color) : getSkillColor("cyan");
                      const levelGain = pred.projectedLevel - pred.currentLevel;
                      return (
                        <Card key={pred.skillId} className="border-border">
                          <CardContent className="p-4 space-y-3">
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <div className={`text-sm font-semibold ${colors.text}`}>{pred.skillName}</div>
                                <div className="text-xs text-muted-foreground mt-0.5">{pred.insight}</div>
                              </div>
                              <div className="text-right flex-shrink-0">
                                <div className="text-xs text-muted-foreground">Now → 6mo</div>
                                <div className={`text-sm font-bold ${colors.text}`}>
                                  Lv.{pred.currentLevel} → Lv.{pred.projectedLevel}
                                </div>
                              </div>
                            </div>

                            {/* Level gain visualization */}
                            <div className="flex items-center gap-1.5">
                              {Array.from({ length: Math.max(pred.projectedLevel, 5) }).map((_, i) => (
                                <div
                                  key={i}
                                  className={`flex-1 h-1.5 rounded-full transition-all ${
                                    i < pred.currentLevel
                                      ? colors.bg.replace("/10", "/80")
                                      : i < pred.projectedLevel
                                      ? colors.bg.replace("/10", "/30") + " border " + colors.border.replace("/40", "/20")
                                      : "bg-muted"
                                  }`}
                                />
                              ))}
                            </div>

                            {levelGain > 0 && (
                              <Badge variant="outline" className={`text-xs ${colors.border} ${colors.text}`}>
                                +{levelGain} levels in 6 months
                              </Badge>
                            )}

                            {pred.tips.length > 0 && (
                              <div className="space-y-1">
                                {pred.tips.slice(0, 2).map((tip, i) => (
                                  <div key={i} className="flex items-start gap-1.5 text-xs text-muted-foreground">
                                    <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0 text-primary/60" />
                                    <span>{tip}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Chat Tab */}
        {activeTab === "chat" && (
          <div className="space-y-4">
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-accent" />
                  AI Life Advisor
                  <Badge variant="outline" className="ml-auto text-xs border-accent/30 text-accent">Online</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Quick prompts */}
                {chatMessages.length === 0 && (
                  <div className="space-y-2">
                    <p className="text-xs text-muted-foreground">Ask the AI advisor anything about your progress:</p>
                    <div className="flex flex-wrap gap-2">
                      {[
                        "What should I focus on this week?",
                        "How can I improve my streak?",
                        "Give me a workout plan",
                        "What's my biggest weakness?",
                        "How do I level up faster?",
                      ].map((prompt) => (
                        <button
                          key={prompt}
                          onClick={() => { setChatInput(prompt); }}
                          className="text-xs px-3 py-1.5 rounded-md border border-border/50 text-muted-foreground transition-all hover-elevate"
                          data-testid={`quick-prompt-${prompt.slice(0, 10)}`}
                        >
                          {prompt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Messages */}
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {chatMessages.map((msg, i) => (
                    <div
                      key={i}
                      className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                      data-testid={`chat-message-${i}`}
                    >
                      {msg.role === "assistant" && (
                        <div className="w-7 h-7 rounded-md bg-primary/20 border border-primary/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Brain className="w-3.5 h-3.5 text-primary" />
                        </div>
                      )}
                      <div
                        className={`max-w-[80%] p-3 rounded-md text-sm leading-relaxed ${
                          msg.role === "user"
                            ? "bg-primary/20 border border-primary/30 text-foreground"
                            : "bg-muted border border-border/50 text-foreground"
                        }`}
                      >
                        {msg.content}
                      </div>
                    </div>
                  ))}
                  {sendChat.isPending && (
                    <div className="flex gap-3">
                      <div className="w-7 h-7 rounded-md bg-primary/20 border border-primary/30 flex items-center justify-center flex-shrink-0">
                        <RefreshCw className="w-3.5 h-3.5 text-primary animate-spin" />
                      </div>
                      <div className="p-3 rounded-md bg-muted border border-border/50 text-sm text-muted-foreground">
                        Thinking...
                      </div>
                    </div>
                  )}
                </div>

                {/* Input */}
                <div className="flex gap-2">
                  <Textarea
                    placeholder="Ask Optimus Prime anything..."
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendChat();
                      }
                    }}
                    className="resize-none min-h-0 h-10"
                    data-testid="input-chat-message"
                  />
                  <Button
                    size="icon"
                    onClick={handleSendChat}
                    disabled={!chatInput.trim() || sendChat.isPending}
                    data-testid="button-send-chat"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
