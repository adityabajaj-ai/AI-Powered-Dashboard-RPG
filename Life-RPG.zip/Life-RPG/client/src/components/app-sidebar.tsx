import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { LayoutDashboard, Swords, Flame, Target, Sparkles, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useGameState } from "@/lib/useGameState";
import { getCharacterXpPercentage } from "@/lib/gameStore";

const navItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard, badge: null },
  { title: "Skill Tree", url: "/skills", icon: Swords, badge: null },
  { title: "Daily Habits", url: "/habits", icon: Flame, badge: "🔥" },
  { title: "Quest Goals", url: "/goals", icon: Target, badge: null },
  { title: "Optimus Prime", url: "/insights", icon: Sparkles, badge: "AI" },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { state } = useGameState();
  const { character, habits } = state;
  const completedToday = habits.filter((h) => h.completedToday).length;
  const xpPct = getCharacterXpPercentage(character);

  return (
    <Sidebar>
      <SidebarHeader className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-md bg-primary/20 border border-primary/40 flex items-center justify-center text-lg glow-primary">
            <Swords className="w-5 h-5 text-primary" />
          </div>
          <div>
            <div className="font-bold text-sm text-foreground tracking-wide">Life RPG</div>
            <div className="text-xs text-muted-foreground">Level Up Your Reality</div>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup className="pt-4">
          <div className="mx-3 mb-4 p-3 rounded-md bg-sidebar-accent border border-sidebar-border">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground font-medium">
                {character.name}
              </span>
              <Badge variant="secondary" className="text-xs px-1.5 py-0 h-5">
                LVL {character.level}
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground mb-1.5 flex justify-between">
              <span className="text-primary/80 font-medium">{character.class}</span>
              <span>{xpPct}%</span>
            </div>
            <div className="h-1.5 bg-background rounded-full overflow-hidden">
              <div
                className="h-full xp-bar-fill rounded-full transition-all duration-700"
                style={{ width: `${xpPct}%` }}
              />
            </div>
          </div>

          <SidebarGroupLabel className="text-xs text-muted-foreground uppercase tracking-widest px-3">
            Navigation
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-active={isActive}>
                      <Link href={item.url} className={`flex items-center gap-3 px-3 py-2 rounded-md transition-all ${isActive ? "bg-primary/15 text-primary border border-primary/25" : "text-sidebar-foreground"}`}>
                        <item.icon className={`w-4 h-4 flex-shrink-0 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
                        <span className="flex-1 text-sm font-medium">{item.title}</span>
                        {item.badge === "AI" && (
                          <Badge className="text-xs px-1.5 py-0 h-4 bg-accent/20 text-accent border-accent/30" variant="outline">
                            AI
                          </Badge>
                        )}
                        {item.badge === "🔥" && completedToday > 0 && (
                          <span className="text-xs text-orange-400 font-bold">{completedToday}</span>
                        )}
                        {isActive && <ChevronRight className="w-3 h-3 text-primary" />}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-3 border-t border-sidebar-border">
        <div className="flex items-center gap-2 px-1">
          <div className="w-8 h-8 rounded-md bg-primary/20 border border-primary/30 flex items-center justify-center text-sm">
            {character.avatar}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-medium text-foreground truncate">{character.name}</div>
            <div className="text-xs text-muted-foreground truncate">{character.title}</div>
          </div>
          <div className="text-xs text-primary font-bold">{character.totalXp} XP</div>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
