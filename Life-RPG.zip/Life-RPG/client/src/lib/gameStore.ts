export type SkillCategory = "combat" | "intellect" | "creativity" | "social" | "wellness" | "tech";

export interface Skill {
  id: string;
  name: string;
  category: SkillCategory;
  description: string;
  level: number;
  xp: number;
  xpToNext: number;
  icon: string;
  color: string;
  unlockedAt: number;
  lastPracticed?: string;
  totalPractices: number;
}

export interface Habit {
  id: string;
  name: string;
  description: string;
  skillId: string;
  xpReward: number;
  streak: number;
  longestStreak: number;
  completedToday: boolean;
  completedDates: string[];
  createdAt: string;
  icon: string;
  frequency: "daily" | "weekly";
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  skillId: string;
  targetDate: string;
  progress: number;
  status: "active" | "completed" | "paused";
  milestones: Milestone[];
  xpReward: number;
  createdAt: string;
  completedAt?: string;
}

export interface Milestone {
  id: string;
  title: string;
  completed: boolean;
  completedAt?: string;
}

export interface Character {
  name: string;
  title: string;
  level: number;
  totalXp: number;
  xpToNextLevel: number;
  avatar: string;
  class: string;
  joinedAt: string;
  lastActive: string;
}

export interface GameState {
  character: Character;
  skills: Skill[];
  habits: Habit[];
  goals: Goal[];
  totalXpEarned: number;
}

const STORAGE_KEY = "rpg-life-dashboard";

function getXpForLevel(level: number): number {
  return Math.floor(100 * Math.pow(1.5, level - 1));
}

function getCharacterLevel(totalXp: number): { level: number; xpToNext: number; xpIntoLevel: number } {
  let level = 1;
  let xpUsed = 0;
  while (true) {
    const needed = getXpForLevel(level);
    if (xpUsed + needed > totalXp) {
      return { level, xpToNext: needed, xpIntoLevel: totalXp - xpUsed };
    }
    xpUsed += needed;
    level++;
  }
}

const defaultSkills: Skill[] = [
  {
    id: "coding",
    name: "Coding",
    category: "tech",
    description: "Software development and programming mastery",
    level: 1, xp: 0, xpToNext: 100,
    icon: "Code2", color: "cyan",
    unlockedAt: 1, totalPractices: 0,
  },
  {
    id: "fitness",
    name: "Fitness",
    category: "wellness",
    description: "Physical strength and endurance training",
    level: 1, xp: 0, xpToNext: 100,
    icon: "Dumbbell", color: "green",
    unlockedAt: 1, totalPractices: 0,
  },
  {
    id: "reading",
    name: "Reading",
    category: "intellect",
    description: "Knowledge acquisition through literature",
    level: 1, xp: 0, xpToNext: 100,
    icon: "BookOpen", color: "amber",
    unlockedAt: 1, totalPractices: 0,
  },
  {
    id: "meditation",
    name: "Mindfulness",
    category: "wellness",
    description: "Mental clarity and stress reduction",
    level: 1, xp: 0, xpToNext: 100,
    icon: "Brain", color: "purple",
    unlockedAt: 1, totalPractices: 0,
  },
  {
    id: "creativity",
    name: "Creativity",
    category: "creativity",
    description: "Art, music, writing and creative expression",
    level: 1, xp: 0, xpToNext: 100,
    icon: "Palette", color: "pink",
    unlockedAt: 1, totalPractices: 0,
  },
  {
    id: "social",
    name: "Social",
    category: "social",
    description: "Communication and relationship building",
    level: 1, xp: 0, xpToNext: 100,
    icon: "Users", color: "orange",
    unlockedAt: 1, totalPractices: 0,
  },
];

const defaultHabits: Habit[] = [
  {
    id: "h1", name: "Morning Workout", description: "30 minutes of exercise",
    skillId: "fitness", xpReward: 30, streak: 0, longestStreak: 0,
    completedToday: false, completedDates: [], createdAt: new Date().toISOString(),
    icon: "Dumbbell", frequency: "daily",
  },
  {
    id: "h2", name: "Code Practice", description: "1 hour of coding",
    skillId: "coding", xpReward: 40, streak: 0, longestStreak: 0,
    completedToday: false, completedDates: [], createdAt: new Date().toISOString(),
    icon: "Code2", frequency: "daily",
  },
  {
    id: "h3", name: "Read 20 Pages", description: "Daily reading habit",
    skillId: "reading", xpReward: 20, streak: 0, longestStreak: 0,
    completedToday: false, completedDates: [], createdAt: new Date().toISOString(),
    icon: "BookOpen", frequency: "daily",
  },
  {
    id: "h4", name: "Meditate", description: "10 minutes of mindfulness",
    skillId: "meditation", xpReward: 25, streak: 0, longestStreak: 0,
    completedToday: false, completedDates: [], createdAt: new Date().toISOString(),
    icon: "Brain", frequency: "daily",
  },
];

const defaultGoals: Goal[] = [
  {
    id: "g1",
    title: "Build a Full-Stack App",
    description: "Create a complete web application from scratch",
    skillId: "coding",
    targetDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    progress: 0,
    status: "active",
    milestones: [
      { id: "m1", title: "Design the schema", completed: false },
      { id: "m2", title: "Build the backend API", completed: false },
      { id: "m3", title: "Create the frontend", completed: false },
      { id: "m4", title: "Deploy to production", completed: false },
    ],
    xpReward: 500,
    createdAt: new Date().toISOString(),
  },
  {
    id: "g2",
    title: "Run a 5K",
    description: "Complete a 5 kilometer run without stopping",
    skillId: "fitness",
    targetDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    progress: 0,
    status: "active",
    milestones: [
      { id: "m5", title: "Run 1K without stopping", completed: false },
      { id: "m6", title: "Run 3K", completed: false },
      { id: "m7", title: "Complete full 5K", completed: false },
    ],
    xpReward: 300,
    createdAt: new Date().toISOString(),
  },
];

const defaultState: GameState = {
  character: {
    name: "Hero",
    title: "The Awakened",
    level: 1,
    totalXp: 0,
    xpToNextLevel: 100,
    avatar: "⚔️",
    class: "Adventurer",
    joinedAt: new Date().toISOString(),
    lastActive: new Date().toISOString(),
  },
  skills: defaultSkills,
  habits: defaultHabits,
  goals: defaultGoals,
  totalXpEarned: 0,
};

export function loadState(): GameState {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as GameState;
      return resetDailyHabits(parsed);
    }
  } catch (e) {
    console.error("Failed to load state", e);
  }
  return { ...defaultState };
}

export function saveState(state: GameState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error("Failed to save state", e);
  }
}

function resetDailyHabits(state: GameState): GameState {
  const today = new Date().toDateString();
  const habits = state.habits.map((h) => {
    const lastCompleted = h.completedDates[h.completedDates.length - 1];
    if (lastCompleted && new Date(lastCompleted).toDateString() !== today) {
      return { ...h, completedToday: false };
    }
    return h;
  });
  return { ...state, habits };
}

export function addXpToSkill(state: GameState, skillId: string, xp: number): GameState {
  const skills = state.skills.map((s) => {
    if (s.id !== skillId) return s;
    let newXp = s.xp + xp;
    let newLevel = s.level;
    let xpToNext = s.xpToNext;
    while (newXp >= xpToNext) {
      newXp -= xpToNext;
      newLevel++;
      xpToNext = Math.floor(100 * Math.pow(1.4, newLevel - 1));
    }
    return { ...s, xp: newXp, level: newLevel, xpToNext, totalPractices: s.totalPractices + 1, lastPracticed: new Date().toISOString() };
  });
  const newTotalXp = state.character.totalXp + xp;
  const { level, xpToNext, xpIntoLevel } = getCharacterLevel(newTotalXp);
  return {
    ...state,
    skills,
    totalXpEarned: state.totalXpEarned + xp,
    character: {
      ...state.character,
      totalXp: newTotalXp,
      level,
      xpToNextLevel: xpToNext,
      lastActive: new Date().toISOString(),
    },
  };
}

export function completeHabit(state: GameState, habitId: string): GameState {
  const today = new Date().toISOString();
  let xpGained = 0;
  let skillId = "";

  const habits = state.habits.map((h) => {
    if (h.id !== habitId || h.completedToday) return h;
    xpGained = h.xpReward;
    skillId = h.skillId;
    const newStreak = h.streak + 1;
    return {
      ...h,
      completedToday: true,
      streak: newStreak,
      longestStreak: Math.max(h.longestStreak, newStreak),
      completedDates: [...h.completedDates, today],
    };
  });

  let newState = { ...state, habits };
  if (xpGained > 0 && skillId) {
    newState = addXpToSkill(newState, skillId, xpGained);
  }
  return newState;
}

export function getSkillColor(color: string): { text: string; bg: string; border: string; glow: string } {
  const colors: Record<string, { text: string; bg: string; border: string; glow: string }> = {
    cyan: { text: "text-cyan-400", bg: "bg-cyan-400/10", border: "border-cyan-400/40", glow: "shadow-cyan-400/20" },
    green: { text: "text-emerald-400", bg: "bg-emerald-400/10", border: "border-emerald-400/40", glow: "shadow-emerald-400/20" },
    amber: { text: "text-amber-400", bg: "bg-amber-400/10", border: "border-amber-400/40", glow: "shadow-amber-400/20" },
    purple: { text: "text-purple-400", bg: "bg-purple-400/10", border: "border-purple-400/40", glow: "shadow-purple-400/20" },
    pink: { text: "text-pink-400", bg: "bg-pink-400/10", border: "border-pink-400/40", glow: "shadow-pink-400/20" },
    orange: { text: "text-orange-400", bg: "bg-orange-400/10", border: "border-orange-400/40", glow: "shadow-orange-400/20" },
  };
  return colors[color] || colors.cyan;
}

export function getXpPercentage(skill: Skill): number {
  return Math.min(100, Math.round((skill.xp / skill.xpToNext) * 100));
}

export function getCharacterXpPercentage(character: Character): number {
  const { xpIntoLevel } = getCharacterLevelInfo(character.totalXp);
  return Math.min(100, Math.round((xpIntoLevel / character.xpToNextLevel) * 100));
}

function getCharacterLevelInfo(totalXp: number): { level: number; xpToNext: number; xpIntoLevel: number } {
  let level = 1;
  let xpUsed = 0;
  while (true) {
    const needed = getXpForLevel(level);
    if (xpUsed + needed > totalXp) {
      return { level, xpToNext: needed, xpIntoLevel: totalXp - xpUsed };
    }
    xpUsed += needed;
    level++;
  }
}

export { getCharacterLevelInfo };
