import { useState, useCallback } from "react";
import {
  type GameState,
  loadState,
  saveState,
  completeHabit,
  addXpToSkill,
} from "./gameStore";

let globalState: GameState = loadState();
const listeners: Array<() => void> = [];

function notifyListeners() {
  listeners.forEach((l) => l());
}

export function useGameState() {
  const [, setTick] = useState(0);

  const forceUpdate = useCallback(() => setTick((t) => t + 1), []);

  if (!listeners.includes(forceUpdate)) {
    listeners.push(forceUpdate);
  }

  const setState = useCallback((newState: GameState) => {
    globalState = newState;
    saveState(newState);
    notifyListeners();
  }, []);

  const handleCompleteHabit = useCallback(
    (habitId: string) => {
      const newState = completeHabit(globalState, habitId);
      setState(newState);
    },
    [setState]
  );

  const handleAddXp = useCallback(
    (skillId: string, xp: number) => {
      const newState = addXpToSkill(globalState, skillId, xp);
      setState(newState);
    },
    [setState]
  );

  const handleAddSkill = useCallback(
    (skill: GameState["skills"][0]) => {
      const newState = { ...globalState, skills: [...globalState.skills, skill] };
      setState(newState);
    },
    [setState]
  );

  const handleAddHabit = useCallback(
    (habit: GameState["habits"][0]) => {
      const newState = { ...globalState, habits: [...globalState.habits, habit] };
      setState(newState);
    },
    [setState]
  );

  const handleAddGoal = useCallback(
    (goal: GameState["goals"][0]) => {
      const newState = { ...globalState, goals: [...globalState.goals, goal] };
      setState(newState);
    },
    [setState]
  );

  const handleUpdateGoal = useCallback(
    (goal: GameState["goals"][0]) => {
      const goals = globalState.goals.map((g) => (g.id === goal.id ? goal : g));
      const newState = { ...globalState, goals };
      setState(newState);
    },
    [setState]
  );

  const handleUpdateCharacter = useCallback(
    (updates: Partial<GameState["character"]>) => {
      const newState = { ...globalState, character: { ...globalState.character, ...updates } };
      setState(newState);
    },
    [setState]
  );

  const handleDeleteHabit = useCallback(
    (habitId: string) => {
      const habits = globalState.habits.filter((h) => h.id !== habitId);
      setState({ ...globalState, habits });
    },
    [setState]
  );

  const handleDeleteGoal = useCallback(
    (goalId: string) => {
      const goals = globalState.goals.filter((g) => g.id !== goalId);
      setState({ ...globalState, goals });
    },
    [setState]
  );

  return {
    state: globalState,
    completeHabit: handleCompleteHabit,
    addXp: handleAddXp,
    addSkill: handleAddSkill,
    addHabit: handleAddHabit,
    addGoal: handleAddGoal,
    updateGoal: handleUpdateGoal,
    updateCharacter: handleUpdateCharacter,
    deleteHabit: handleDeleteHabit,
    deleteGoal: handleDeleteGoal,
  };
}
