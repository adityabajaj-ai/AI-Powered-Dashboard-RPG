# Life RPG Dashboard

## Project Overview
An AI-powered gamified life dashboard that turns real-life goals and habits into an RPG-style progression system with skill trees and AI-generated insights.

## Architecture
- **Frontend**: React + TypeScript + Tailwind CSS (90% of the app)
- **Backend**: Express + Node.js with OpenAI AI Integrations
- **Storage**: localStorage (no database required)
- **Routing**: wouter

## Key Features
- **Dashboard**: Character overview with level, XP bar, today's quests, skill rankings, weekly activity heatmap
- **Skill Tree**: Visual skill nodes, XP tracking, level progression, add custom skills
- **Daily Habits**: Habit tracker with streaks, XP rewards linked to skills, completion tracking
- **Quest Goals**: Goal management with milestones, progress tracking, completion rewards
- **AI Oracle**: 6-month skill predictions, motivational analysis, AI chat advisor

## Design System
- Dark RPG theme with deep navy/purple backgrounds
- Primary: Purple (hsl 265 80% 65%)
- Accent: Cyan (hsl 190 90% 55%)
- Font: Outfit (sans-serif)
- Custom glow effects, XP bars, skill node animations

## Backend API
- `POST /api/insights/generate` - Generate 6-month AI predictions for skills
- `POST /api/insights/chat` - AI life advisor chat

## AI Integration
Uses Replit AI Integrations (OpenAI-compatible) - no API key required, billed to credits.
Model: gpt-5-mini for insights and chat.

## File Structure
- `client/src/pages/` - Dashboard, Skills, Habits, Goals, Insights
- `client/src/components/app-sidebar.tsx` - Navigation sidebar
- `client/src/lib/gameStore.ts` - Game data types, XP calculations, localStorage
- `client/src/lib/useGameState.ts` - React state management hook
- `server/routes.ts` - AI API endpoints
